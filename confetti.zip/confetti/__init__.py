import json
from aqt import gui_hooks, mw
from aqt.utils import showInfo
from aqt.qt import QTimer, QUrl

# Import QWebEngineView from PyQt5 if available, else PyQt6.
try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
except ImportError:
    from PyQt6.QtWebEngineWidgets import QWebEngineView

# Import QSoundEffect from PyQt5 if available, else PyQt6.
try:
    from PyQt5.QtMultimedia import QSoundEffect
    SOUND_EFFECT_AVAILABLE = True
except ImportError:
    try:
        from PyQt6.QtMultimedia import QSoundEffect
        SOUND_EFFECT_AVAILABLE = True
    except ImportError:
        SOUND_EFFECT_AVAILABLE = False

# Aliases for FSRS properties.
ALIAS_MAP = {
    "d": "difficulty",
    "r": "retrievability",
    "s": "stability"
}

def load_config():
    config = mw.addonManager.getConfig(__name__)
    if config is None:
        config = {
            "play_success_sound": False,
            "success_sound": "/absolute/path/to/your/success_sound.wav",
            "default_origins": [ {"x": 0.1, "y": 1.0}, {"x": 0.9, "y": 1.0} ],
            "default_particleCount": 100,
            "default_spread": 70,
            "default_speed": 45,
            "default_duration": 200,
            "default_fade": 0.9,
            "triggers": [
                {
                    "name": "Low retrievability & enough reps",
                    "conditions": {
                        "prop:r": "< 0.40",
                        "prop:reps": ">= 3"
                    },
                    "pattern": {
                        "particleCount": 150,
                        "spread": 120,
                        "speed": 55,
                        "duration": 220,
                        "fade": 0.85
                    }
                },
                {
                    "name": "Review card with high difficulty",
                    "conditions": {
                        "is:review": True,
                        "prop:d": ">= 0.90"
                    },
                    "pattern": {
                        "particleCount": 180,
                        "spread": 100,
                        "speed": 50,
                        "duration": 230,
                        "fade": 0.8
                    }
                },
                {
                    "name": "Three consecutive 'again'",
                    "conditions": {
                        "last_n_again": 3
                    },
                    "pattern": {
                        "particleCount": 150,
                        "spread": 100,
                        "speed": 55,
                        "duration": 210,
                        "fade": 0.9
                    }
                },
                {
                    "name": "Overdue card with no recent 'again'",
                    "conditions": {
                        "prop:due": "< -24",
                        "last_n_again": 0
                    },
                    "pattern": {
                        "particleCount": 200,
                        "spread": 120,
                        "speed": 65,
                        "duration": 250,
                        "fade": 0.8
                    }
                },
                {
                    "name": "High difficulty on review",
                    "conditions": {
                        "prop:d": "> 0.90",
                        "is:review": True
                    },
                    "pattern": {
                        "particleCount": 180,
                        "spread": 90,
                        "speed": 50,
                        "duration": 200,
                        "fade": 0.8
                    }
                },
                {
                    "name": "Very low retrievability",
                    "conditions": {
                        "prop:r": "<= 0.30"
                    },
                    "pattern": {
                        "particleCount": 160,
                        "spread": 100,
                        "speed": 55,
                        "duration": 210,
                        "fade": 0.85
                    }
                },
                {
                    "name": "Moderately overdue with no 'again'",
                    "conditions": {
                        "prop:due": "<= -15",
                        "last_n_again": 0
                    },
                    "pattern": {
                        "particleCount": 180,
                        "spread": 120,
                        "speed": 65,
                        "duration": 200,
                        "fade": 0.8
                    }
                },
                {
                    "name": "Extremely low ease with one 'again'",
                    "conditions": {
                        "prop:ease": "<= 1",
                        "last_n_again": 1
                    },
                    "pattern": {
                        "particleCount": 200,
                        "spread": 150,
                        "speed": 65,
                        "duration": 230,
                        "fade": 0.9
                    }
                },
                {
                    "name": "Mixed 'again' or 'hard' over last 4 reviews",
                    "conditions": {
                        "last_n_again|hard": 4
                    },
                    "pattern": {
                        "particleCount": 190,
                        "spread": 130,
                        "speed": 60,
                        "duration": 240,
                        "fade": 0.85
                    }
                }
            ],
            "guide": "Configuration Guide for Confetti Reinforcement Add-on:\n\n" +
                     "Global Options:\n" +
                     "  - default_origins: A list of origins (x,y between 0 and 1) for all confetti bursts.\n" +
                     "       Default: [ {\"x\": 0.1, \"y\": 1.0}, {\"x\": 0.9, \"y\": 1.0} ]\n" +
                     "  - default_particleCount: Default number of particles (e.g., 100).\n" +
                     "  - default_spread: Default spread angle (e.g., 70).\n" +
                     "  - default_speed: Default start velocity (e.g., 45).\n" +
                     "  - default_duration: Default overall duration in ticks (e.g., 200).\n" +
                     "  - default_fade: Default fade duration (decay factor, e.g., 0.9).\n\n" +
                     "Triggers (conditions are combined with logical AND):\n" +
                     "  1. 'Low retrievability & enough reps': prop:r < 0.40 AND prop:reps >= 3\n" +
                     "  2. 'Review card with high difficulty': is:review AND prop:d >= 0.90\n" +
                     "  3. 'Three consecutive \"again\"': last_n_again = 3\n" +
                     "  4. 'Overdue card with no recent \"again\"': prop:due < -24 AND last_n_again = 0\n" +
                     "  5. 'High difficulty on review': prop:d > 0.90 AND is:review\n" +
                     "  6. 'Very low retrievability': prop:r <= 0.30\n" +
                     "  7. 'Moderately overdue with no \"again\"': prop:due <= -15 AND last_n_again = 0\n" +
                     "  8. 'Extremely low ease with one \"again\"': prop:ease <= 1 AND last_n_again = 1\n" +
                     "  9. 'Mixed \"again\" or \"hard\" over last 4 reviews': last_n_again|hard = 4\n\n" +
                     "Note: Confetti is fired only if the card is rated 'good' or 'easy' (ease value 3 or 4) and the trigger conditions are met."
        }
        mw.addonManager.writeConfig(__name__, config)
    return config

def play_success_sound(config):
    if not config.get("play_success_sound", False):
        return
    sound_path = config.get("success_sound", "")
    if not sound_path:
        return
    if SOUND_EFFECT_AVAILABLE:
        try:
            sound = QSoundEffect()
            sound.setSource(QUrl.fromLocalFile(sound_path))
            sound.setVolume(0.5)
            sound.play()
        except Exception as e:
            showInfo("Unable to play sound (Qt): " + str(e))
    else:
        try:
            from aqt.sound import play
            play(sound_path)
        except Exception as e:
            showInfo("Unable to play sound: " + str(e))

def evaluate_numeric_condition(prop_value, condition_str):
    operators = ["<=", ">=", "<", ">", "==", "!="]
    for op in operators:
        if condition_str.startswith(op):
            try:
                threshold = float(condition_str[len(op):].strip())
                try:
                    value = float(prop_value)
                except (ValueError, TypeError):
                    return False
                if op == "<":
                    return value < threshold
                elif op == "<=":
                    return value <= threshold
                elif op == ">":
                    return value > threshold
                elif op == ">=":
                    return value >= threshold
                elif op == "==":
                    return value == threshold
                elif op == "!=":
                    return value != threshold
            except Exception:
                return False
    return False

def evaluate_conditions(conditions, card, ease, revlog):
    if "last_n_again" in conditions:
        n = conditions["last_n_again"]
        if len(revlog) < n or not all(r.ease == 1 for r in revlog[-n:]):
            return False
    if "last_n_again|hard" in conditions:
        n = conditions["last_n_again|hard"]
        if len(revlog) < n or not all(r.ease in (1, 2) for r in revlog[-n:]):
            return False
    if "rating" in conditions:
        rating_mapping = {"again": 1, "hard": 2, "good": 3, "easy": 4}
        desired = conditions["rating"].lower()
        if ease != rating_mapping.get(desired, 0):
            return False
    if "type" in conditions:
        desired_type = conditions["type"].lower()
        if desired_type == "review" and getattr(card, "queue", None) != 2:
            return False
        if desired_type == "learn" and getattr(card, "queue", None) != 1:
            return False
        if desired_type == "new" and getattr(card, "queue", None) != 0:
            return False
    if "not_type" in conditions:
        not_type = conditions["not_type"].lower()
        if not_type == "review" and getattr(card, "queue", None) == 2:
            return False
        if not_type == "learn" and getattr(card, "queue", None) == 1:
            return False
        if not_type == "new" and getattr(card, "queue", None) == 0:
            return False
    for key, cond in conditions.items():
        if key in {"last_n_again", "last_n_again|hard", "rating", "type", "not_type"}:
            continue
        if key.startswith("is:"):
            expected = key[3:].lower()
            mapping = {"new": 0, "learn": 1, "review": 2}
            if mapping.get(expected, -1) != getattr(card, "queue", -1):
                return False
            continue
        if key.startswith("tag:"):
            tag_required = key[4:].lower()
            card_tags = [t.lower() for t in getattr(card, "tags", [])]
            if tag_required not in card_tags:
                return False
            continue
        effective_key = key[5:] if key.startswith("prop:") else key
        effective_key = ALIAS_MAP.get(effective_key, effective_key)
        card_val = getattr(card, effective_key, None)
        if card_val is None:
            return False
        if isinstance(cond, str) and cond.strip() and cond.strip()[0] in "<>!=":
            if not evaluate_numeric_condition(card_val, cond):
                return False
        else:
            if str(card_val).lower() != str(cond).lower():
                return False
    return True

def choose_pattern(card, ease, revlog, config):
    for trigger in config.get("triggers", []):
        conditions = trigger.get("conditions", {})
        if evaluate_conditions(conditions, card, ease, revlog):
            return trigger.get("pattern")
    return None

def inject_confetti(reviewer, card, ease):
    if ease not in (3, 4):
        return
    config = load_config()
    try:
        webview = reviewer.web
    except Exception as e:
        showInfo("Unable to access review webview: " + str(e))
        return
    revlog = getattr(card, "revs", [])
    pattern = choose_pattern(card, ease, revlog, config)
    if not pattern:
        return
    origins = config.get("default_origins", [ {"x": 0.1, "y": 1.0}, {"x": 0.9, "y": 1.0} ])
    particle_count = pattern.get("particleCount", config.get("default_particleCount", 100))
    spread = pattern.get("spread", config.get("default_spread", 70))
    start_velocity = pattern.get("speed", config.get("default_speed", 45))
    ticks = pattern.get("duration", config.get("default_duration", 200))
    fade = pattern.get("fade", config.get("default_fade", 0.9))
    origins_json = json.dumps(origins)
    js_code = f"""
    (function() {{
        function fireConfetti(origin) {{
            confetti({{
                particleCount: {particle_count},
                spread: {spread},
                origin: origin,
                startVelocity: {start_velocity},
                ticks: {ticks},
                decay: {fade}
            }});
        }}
        var origins = {origins_json};
        if (typeof confetti === 'undefined') {{
            let script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1';
            script.onload = function() {{
                origins.forEach(fireConfetti);
            }};
            document.head.appendChild(script);
        }} else {{
            origins.forEach(fireConfetti);
        }}
    }})();
    """
    QTimer.singleShot(100, lambda: webview.page().runJavaScript(js_code))
    play_success_sound(config)

def init_confetti_addon():
    gui_hooks.reviewer_did_answer_card.append(inject_confetti)

init_confetti_addon()
